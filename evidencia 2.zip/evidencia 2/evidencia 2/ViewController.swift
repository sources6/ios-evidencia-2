//
//  ViewController.swift
//  evidencia 2
//
//  Created by Alumno on 08/04/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

